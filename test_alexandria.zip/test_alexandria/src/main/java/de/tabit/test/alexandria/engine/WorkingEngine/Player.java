package de.tabit.test.alexandria.engine.WorkingEngine;

public class Player {
    int playerNum;
    int position;
    boolean hasJoker;
    boolean skipTurn;

    Player(int playerNum) {
        this.playerNum = playerNum;
        this.position = -1;
        this.hasJoker = false;
        this.skipTurn = false;
    }

    int incrementPosition(int input) {
        this.position += input;
        return this.position;
    }

    int decrementPosition(int input) {
        this.position -= input;
        if(this.position < 1) {
            this.position += input;
        }
        return this.position;
    }
}
