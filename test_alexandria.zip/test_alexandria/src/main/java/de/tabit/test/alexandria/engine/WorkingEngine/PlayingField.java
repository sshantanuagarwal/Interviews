package de.tabit.test.alexandria.engine.WorkingEngine;


import java.util.ArrayList;
import java.util.Collections;

public class PlayingField {
    static final int numFields = 30;

    Position[] positions;

    public String printBoardBonusTrap() {
        char[] result = new char[numFields];
        for(int i = 0; i < numFields; i++) {
            if (positions[i].type == null) {
                result[i] = '_';
            } else if (positions[i].isTrapType()) {
                result[i] = 'T';
            } else if (positions[i].isBonusType()) {
                result[i] = 'B';
            }
        }
        return String.valueOf(result) + "\n";
    }

    public PlayingField() {
        positions =  new Position[numFields];
        ArrayList<String> types = new ArrayList<>();
        for(int i = 0; i < 5; i++) {
            types.add("trap");
            types.add("bonus");
        }
        for(int i = 0; i < 20; i++) {
            types.add(null);
        }
        Collections.shuffle(types);

        for(int i = 0; i < this.numFields; i++) {
            this.positions[i] = new Position(i+1, types.get(i) );
        }
    }
}
