public class User {

    Integer id;
    String name;
    String email;
    String phoneNo;

    public User(Integer id, String name, String email, String phone ) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNo = phone;
    }


}
